import 'package:flutter/material.dart';

const primary =   Color.fromARGB(255, 52, 47, 86);