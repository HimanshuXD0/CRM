package com.example.crm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
